// import 'package:http/http.dart' as http;
// import 'dart:convert';

// class LembagaService {
//   List<dynamic> _lembagaList = [];
//   List<dynamic> _filteredLembagaList = [];
//   bool _isLoading = true;

//   Future<void> _fetchLembagaData() async {
//     final url = Uri.parse('http://phbtegal.com:5013/lembaga');
//     final headers = {
//       'API-Key': '64fb3b903fbd44122f9ba6ac6a5c92d7',
//     };

//     try {
//       final response = await http.get(url, headers: headers);

//       if (response.statusCode == 200) {
//         final List<dynamic> data = json.decode(response.body);
//         setState(() {
//           _lembagaList = data;
//           _filteredLembagaList = _lembagaList;
//           _isLoading = false;
//         });
//       } else {
//         print('Failed to load data: ${response.statusCode}');
//       }
//     } catch (e) {
//       print('Error: $e');
//     }
//   }
// }